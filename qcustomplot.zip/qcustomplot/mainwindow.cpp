#include "mainwindow.h"
#include "ui_mainwindow.h"


#define CanvasBGColor_0     QColor(80, 80, 80)//����������ɫ
#define CanvasBGColor_1     QColor(50, 50, 50)
#define CoorBGColor_0       QColor(80, 80, 80)  //���걳����ɫ
#define CoorBGColor_1       QColor(50, 50, 50)
#define TextColor           QColor(255,255,255)
#define Plot_NoColor        QColor(0,0,0,0)

#define Plot_DotColor       QColor(236,110,0)
#define Plot_LineColor      QColor(180,252,253)
#define Plot_BGColor        QColor(246,98,0,80)

#define TextWidth   1
#define LineWidth   2
#define DotWidth    10

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->resize(800, 600);
    initPlot();
    setupPlot();
}


void MainWindow::initPlot()
{
    //�����ı߶�������
    ui->plot->axisRect()->setupFullAxesBox(true);

    //����������ɫ/����������ɫ
    ui->plot->yAxis->setLabelColor(TextColor);
    ui->plot->xAxis->setLabelColor(TextColor);
    ui->plot->xAxis->setTickLabelColor(TextColor);
    ui->plot->yAxis->setTickLabelColor(TextColor);
    ui->plot->xAxis->setBasePen(QPen(TextColor, TextWidth));
    ui->plot->yAxis->setBasePen(QPen(TextColor, TextWidth));
    ui->plot->xAxis->setTickPen(QPen(TextColor, TextWidth));
    ui->plot->yAxis->setTickPen(QPen(TextColor, TextWidth));
    ui->plot->xAxis->setSubTickPen(QPen(TextColor, TextWidth));
    ui->plot->yAxis->setSubTickPen(QPen(TextColor, TextWidth));
    ui->plot->yAxis2->setLabelColor(TextColor);
    ui->plot->xAxis2->setLabelColor(TextColor);
    ui->plot->xAxis2->setTickLabelColor(TextColor);
    ui->plot->yAxis2->setTickLabelColor(TextColor);
    ui->plot->xAxis2->setBasePen(QPen(TextColor, TextWidth));
    ui->plot->yAxis2->setBasePen(QPen(TextColor, TextWidth));
    ui->plot->xAxis2->setTickPen(QPen(TextColor, TextWidth));
    ui->plot->yAxis2->setTickPen(QPen(TextColor, TextWidth));
    ui->plot->xAxis2->setSubTickPen(QPen(TextColor, TextWidth));
    ui->plot->yAxis2->setSubTickPen(QPen(TextColor, TextWidth));

    ui->plot->xAxis->setAutoTickStep(false);
    ui->plot->xAxis->setTickStep(60);
    ui->plot->yAxis->setAutoTickStep(false);
    ui->plot->yAxis->setTickStep(60);
    // ��������������
    ui->plot->xAxis->setLabel("x");
    ui->plot->yAxis->setLabel("y");
    //���ÿ���ק
    ui->plot->setInteractions(QCP::iRangeDrag|QCP::iRangeZoom);
    //�����������ʾ����
    ui->plot->xAxis->grid()->setSubGridVisible(true);
    ui->plot->yAxis->grid()->setSubGridVisible(true);
    //��������ķֶ�ֵ
    QCPAxisRect *subRectLeft = new QCPAxisRect(ui->plot, false); // false means to not setup default axes
    QCPAxisRect *subRectRight = new QCPAxisRect(ui->plot, false);
    subRectLeft->addAxes(QCPAxis::atBottom | QCPAxis::atLeft);
    subRectRight->addAxes(QCPAxis::atBottom | QCPAxis::atRight);
    subRectLeft->axis(QCPAxis::atLeft)->setAutoTickCount(2);
    subRectRight->axis(QCPAxis::atRight)->setAutoTickCount(2);
    subRectRight->axis(QCPAxis::atBottom)->setAutoTickCount(2);
    subRectLeft->axis(QCPAxis::atBottom)->grid()->setVisible(true);
    //���û�������ɫ
    QLinearGradient plotGradient;
    plotGradient.setStart(0, 0);
    plotGradient.setFinalStop(0, 350);
    plotGradient.setColorAt(0, CanvasBGColor_0);
    plotGradient.setColorAt(1, CanvasBGColor_1);
    ui->plot->setBackground(plotGradient);

    //�������걳��ɫ
    QLinearGradient axisRectGradient;
    axisRectGradient.setStart(0, 0);
    axisRectGradient.setFinalStop(0, 350);
    axisRectGradient.setColorAt(0, CoorBGColor_0);
    axisRectGradient.setColorAt(1, CoorBGColor_1);
    ui->plot->axisRect()->setBackground(axisRectGradient);

    // ������������ʾ��Χ������ֻ�ܿ���Ĭ�Ϸ�Χ
    ui->plot->xAxis->setRange(0, 480);
    ui->plot->yAxis->setRange(0, 480);
}


void MainWindow::setupPlot()
{
    ui->plot->addGraph(); // blue dot
    ui->plot->graph(0)->setPen(QPen(Qt::red));
    ui->plot->graph(0)->setLineStyle(QCPGraph::lsNone);
    ui->plot->graph(0)->setScatterStyle(QCPScatterStyle::ssDisc);
    ui->plot->graph(0)->addData(0, 0);
    ui->plot->replot();
}


MainWindow::~MainWindow()
{
    delete ui;
}
